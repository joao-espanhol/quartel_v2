from django.apps import AppConfig


class SargenteanteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sargenteante'
